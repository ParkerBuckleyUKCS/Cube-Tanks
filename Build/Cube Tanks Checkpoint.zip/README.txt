Welcome to Cube Tanks Checkpoint Build.

Gameplay Instructions:

	-Control Tank with WASD.
	-Pause game with esc, or to go back to the menu to reset.
	-Mouse to aim and shoot
	-When full experience is gained, click a tank choice to level up.

So far the features added are 

1) 	Full tilemap and most of the map 
	completed, minus the ocean which will act as the arena border.
2)	5 Completed player models, including prefabs for guns and bodies.
3) 	a Pause screen
4)	a menu screen
5)	Exp bar and enemy damage functionality
6) 	Enemies track players and will shoot within a radius.
7)	all of the player models are included in the level up screen

Features that are in progress:

1) 6 more player models
2) finishing the map border
3) the menu buttons other than start game
4) a basic enemy movement script
5) a few enemy models, 3-5.